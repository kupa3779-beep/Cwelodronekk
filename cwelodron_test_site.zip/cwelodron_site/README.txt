CWElODRON — test zgody na zapis publicznego IP

Zawartość:
- app.py: strona, regulamin, zapis IP po zgodzie i panel administratora
- requirements.txt: zależności

Uruchomienie lokalne (Python 3.10+):
1. Otwórz terminal w folderze z plikami.
2. Zainstaluj zależności: python -m pip install -r requirements.txt
3. Ustaw hasło administratora i losowy klucz sesji.
   Linux/macOS:
     export ADMIN_PASSWORD='wstaw-mocne-haslo'
     export SECRET_KEY='wstaw-dlugi-losowy-sekret'
   Windows PowerShell:
     $env:ADMIN_PASSWORD='wstaw-mocne-haslo'
     $env:SECRET_KEY='wstaw-dlugi-losowy-sekret'
4. Uruchom: python app.py
5. Otwórz http://127.0.0.1:5000
6. Panel administratora: http://127.0.0.1:5000/admin

Aby sprawdzić z drugiego telefonu, aplikacja musi być wdrożona na serwerze dostępnym przez internet i działać przez HTTPS. Sam lokalny adres 127.0.0.1 nie będzie dostępny na drugim telefonie.

WAŻNE:
- Wdrożenie publiczne wymaga hostingu obsługującego Python/Flask i konfiguracji HTTPS.
- Ustaw mocne ADMIN_PASSWORD oraz SECRET_KEY; nigdy nie udostępniaj ich w kodzie publicznym.
- Kod zapisuje IP w bazie dopiero po przesłaniu formularza z zaznaczoną zgodą. Dostawca hostingu może niezależnie prowadzić własne logi połączeń.
- Przy wdrożeniu za reverse proxy trzeba poprawnie skonfigurować zaufany proxy; nie ufaj bezkrytycznie nagłówkom X-Forwarded-For.
- Ogranicz dostęp do panelu i usuń dane testowe, gdy nie będą potrzebne.
