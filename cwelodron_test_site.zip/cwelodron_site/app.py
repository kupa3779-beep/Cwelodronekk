import os
import sqlite3
from datetime import datetime, timezone
from functools import wraps
from flask import Flask, request, redirect, url_for, session, render_template_string, abort

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY') or 'CHANGE-ME-before-deploy-use-a-long-random-secret'
DB_PATH = os.environ.get('DB_PATH', 'visits.sqlite3')
ADMIN_PASSWORD = os.environ.get('ADMIN_PASSWORD')

HOME = r'''<!doctype html><html lang="pl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>cwelodron</title>
<style>body{margin:0;background:#101010;color:#f5f5f5;font:16px Arial,sans-serif;display:grid;min-height:100vh;place-items:center}.card{width:min(520px,calc(100% - 40px));text-align:center}h1{font-size:42px}a{color:#9ec5ff}button{border:0;border-radius:8px;padding:12px 18px;margin:8px;cursor:pointer;font-size:16px}.primary{background:#fff;color:#111}.muted{background:#333;color:#fff}.terms{display:none;text-align:left;margin-top:25px;padding:18px;background:#1d1d1d;border-radius:10px}.small{font-size:13px;color:#bbb}</style></head><body><main class="card"><h1>cwelodron</h1>
<p><button class="primary" onclick="showTerms()">Akceptuj</button></p>
<p><a href="#regulamin" onclick="showTerms();return false">Regulamin</a></p>
<section id="regulamin" class="terms"><h2>Regulamin testu</h2>
<p>To dobrowolny test techniczny. Jeśli zaznaczysz zgodę i naciśniesz „Potwierdzam”, serwer zapisze Twój publiczny adres IP oraz czas wizyty w celu sprawdzenia działania strony. Dane zobaczy administrator testu. Nie podawaj tu innych danych osobowych.</p>
<p>Możesz odmówić; wtedy aplikacja nie zapisze Twojego IP w bazie testu. Połączenie z hostingiem może jednak być rejestrowane niezależnie przez samego dostawcę hostingu.</p>
<form method="post" action="/consent"><label><input type="checkbox" name="consent" value="yes" required> Przeczytałem/am regulamin i zgadzam się na zapis publicznego IP oraz czasu wizyty.</label><p><button class="primary" type="submit">Potwierdzam zgodę</button><button class="muted" type="button" onclick="document.getElementById('status').textContent='Nie wyrażono zgody. IP nie zostało zapisane przez tę aplikację.'">Odrzucam</button></p><p id="status" class="small"></p></form></section>
<p class="small">Test demonstracyjny — nie wpisuj żadnych haseł ani innych poufnych danych.</p></main><script>function showTerms(){document.getElementById('regulamin').style.display='block';document.getElementById('regulamin').scrollIntoView({behavior:'smooth'});}</script></body></html>'''

LOGIN = r'''<!doctype html><html lang="pl"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Panel administratora</title><style>body{background:#111;color:#fff;font:16px Arial;padding:30px}input,button{padding:10px;margin:6px 0}</style><h1>Panel administratora</h1><form method="post"><label>Hasło administratora<br><input type="password" name="password" required></label><br><button type="submit">Zaloguj</button></form>{% if error %}<p>Nieprawidłowe hasło.</p>{% endif %}</html>'''

DASH = r'''<!doctype html><html lang="pl"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Wizyty</title><style>body{background:#111;color:#eee;font:15px Arial;padding:24px}table{border-collapse:collapse;width:100%}td,th{border:1px solid #555;padding:8px;text-align:left}a{color:#9ec5ff}</style><h1>Zgłoszone zgody</h1><p>Wyświetlane są tylko wizyty zapisane po potwierdzeniu zgody w aplikacji.</p><p><a href="/admin/logout">Wyloguj</a></p><table><tr><th>Data i czas (UTC)</th><th>Publiczne IP</th><th>Przeglądarka (User-Agent)</th></tr>{% for row in rows %}<tr><td>{{row[0]}}</td><td>{{row[1]}}</td><td>{{row[2]}}</td></tr>{% endfor %}</table></html>'''


def db():
    con = sqlite3.connect(DB_PATH)
    con.execute('CREATE TABLE IF NOT EXISTS visits (id INTEGER PRIMARY KEY, visited_at TEXT NOT NULL, ip TEXT NOT NULL, user_agent TEXT NOT NULL)')
    return con


def admin_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not session.get('admin_logged_in'):
            return redirect(url_for('admin_login'))
        return fn(*args, **kwargs)
    return wrapper

@app.get('/')
def home():
    return render_template_string(HOME)

@app.post('/consent')
def consent():
    if request.form.get('consent') != 'yes':
        return 'Zgoda nie została udzielona. IP nie zapisano przez aplikację.', 400
    # Record the connecting address only after the explicit consent POST.
    ip = request.remote_addr or 'unknown'
    now = datetime.now(timezone.utc).isoformat(timespec='seconds')
    user_agent = request.headers.get('User-Agent', '')[:500]
    con = db()
    con.execute('INSERT INTO visits (visited_at, ip, user_agent) VALUES (?, ?, ?)', (now, ip, user_agent))
    con.commit()
    con.close()
    return '''<!doctype html><html lang="pl"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><body style="background:#111;color:#fff;font:18px Arial;text-align:center;padding:60px"><h1>Dziękujemy</h1><p>Zgoda została potwierdzona. Wizyta została zapisana do testu.</p><a style="color:#9ec5ff" href="/">Powrót</a></body></html>'''

@app.route('/admin', methods=['GET', 'POST'])
def admin_login():
    if not ADMIN_PASSWORD:
        return 'Administrator nie ustawił ADMIN_PASSWORD na serwerze. Skonfiguruj zmienną środowiskową.', 503
    if session.get('admin_logged_in'):
        return redirect(url_for('admin_dashboard'))
    error = False
    if request.method == 'POST':
        if request.form.get('password', '') == ADMIN_PASSWORD:
            session.clear()
            session['admin_logged_in'] = True
            return redirect(url_for('admin_dashboard'))
        error = True
    return render_template_string(LOGIN, error=error)

@app.get('/admin/visits')
@admin_required
def admin_dashboard():
    con = db()
    rows = con.execute('SELECT visited_at, ip, user_agent FROM visits ORDER BY id DESC LIMIT 500').fetchall()
    con.close()
    return render_template_string(DASH, rows=rows)

@app.get('/admin/logout')
def admin_logout():
    session.clear()
    return redirect(url_for('admin_login'))

if __name__ == '__main__':
    if not ADMIN_PASSWORD:
        print('UWAGA: ustaw ADMIN_PASSWORD i SECRET_KEY przed uruchomieniem na hostingu.')
    app.run(host='127.0.0.1', port=5000, debug=False)
